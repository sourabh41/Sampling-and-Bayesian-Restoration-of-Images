clc; clear;

load('assignmentImageDenoisingPhantom.mat');
initialState = abs(imageNoisy);
State = initialState;
S = size(State);
newState = zeros(S);
mu = 0;
sigmaG = 0.7;
c = 3;
sigmaN = 1;
gamma = 0.005;
for k = 1:100
    T = c/log(1+k);
    k
    likelihood = initialL(State,initialState,mu,sigmaN);
    for i = 2:S(1)-1
        for j = 2:S(1)-1
           %potential = Potential(State, T,gamma) + likelihood;
           newState = State;
           %newState(i,j) = newState(i,j) + normrnd(0,sigmaN);
           %newLikelihood = initialL(newState,initialState,mu,sigmaN);
           newPotential = Potential(newState, T,gamma); %+ newLikelihood; 
%             if newPotential < potential
%                 potential = newPotential;
%                 State = newState;
%                 likelihood = newLikelihood;
%             else 
%               p = potential/newPotential;
%               e = rand(1);
%                 if e < p
%                     potential = newPotential;
%                     State = newState;
%                     likelihood = newLikelihood;
%                 end
%             end
        end
    end
end